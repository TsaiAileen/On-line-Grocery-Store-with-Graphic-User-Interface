<?php

$link = mysqli_connect("localhost","ec","internet","assignment1");
if (!$link)
   die("Could not connect to Server");

?>